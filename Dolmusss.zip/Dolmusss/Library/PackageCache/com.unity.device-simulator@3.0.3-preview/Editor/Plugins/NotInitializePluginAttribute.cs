namespace UnityEditor.DeviceSimulation
{
    [System.AttributeUsage(System.AttributeTargets.Class)]
    internal class NotInitializePluginAttribute : System.Attribute {}
}

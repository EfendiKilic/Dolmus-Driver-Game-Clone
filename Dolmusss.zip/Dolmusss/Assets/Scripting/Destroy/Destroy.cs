﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
    private Rigidbody DestRb;
    private BoxCollider DestCol;
    private GameObject Player;
    private float speed = 5f;
    private float SuniSayac = 0.5f;
    
    private void Awake()
    {
        DestRb = this.gameObject.GetComponent<Rigidbody>();
        DestCol = this.gameObject.GetComponent<BoxCollider>();
    }
    

    private void Update()
    {
        if (SuniSayac > 0)
        {
            Player = GameObject.FindWithTag("car3");
        }
        speed = Player.GetComponent<Car3Move>().ForwardSpeed;
        DestRb.velocity = Vector3.forward * speed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!(other.gameObject.layer == 14) && (other.gameObject.tag != "Destroyer"))
        {
            Destroy(other.gameObject);
        }   
    }
}

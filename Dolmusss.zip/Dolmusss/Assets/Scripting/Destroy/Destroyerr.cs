﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroyerr : MonoBehaviour
{
    private Rigidbody DestRb;
    private BoxCollider DestCol;
    private GameObject Player;
    private float speed = 5f;
    private float SuniSayac = 0.5f;
    
    private void Awake()
    {
        DestRb = this.gameObject.GetComponent<Rigidbody>();
        DestCol = this.gameObject.GetComponent<BoxCollider>();
    }
    

    private void Update()
    {
        if (SuniSayac > 0)
        {
            Player = GameObject.FindWithTag("car2");
        }
        speed = Player.GetComponent<Car2Move>().ForwardSpeed;
        DestRb.velocity = Vector3.forward * speed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!(other.gameObject.layer == 14))
        {
            Destroy(other.gameObject);
        }   
    }
}

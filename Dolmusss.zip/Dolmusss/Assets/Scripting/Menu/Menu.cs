﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    private GameObject Entry;
    private Button PlayButton;
    private Button QuitButton;
    private Button SettingsButton;
    private Button HowtoPlayButton;
    
    private GameObject Settings;
    /*
    private Button VoiceButton;
    private Text VoiceText;
    private Button MusicButton;
    */
    private Button BackButton1;
    
    private GameObject HowtoPlay;
    private Button BackButton2;

    private GameObject ChooseCar;
    private Button BackButton3;
    private Button Car1Button;
    private Button Car2Button;
    private Button Car3Button;
    private Button Car4Button;
    
    private GameObject WayPanel;
    private Button way1Button;
    private Button way2Button;
    private Button BackButton4;

    private int TotalMoney = 0;
    public bool VoiceCheck = true;
    private int Edit = 0;
    
    private void Awake()
    {
        Entry = GameObject.Find("Entry");
        PlayButton = GameObject.Find("PlayButton").GetComponent<Button>();
        QuitButton = GameObject.Find("QuitButton").GetComponent<Button>();
        SettingsButton = GameObject.Find("SettingsButton").GetComponent<Button>();
        HowtoPlayButton = GameObject.Find("HowToPlayButton").GetComponent<Button>();
        
        Settings = GameObject.Find("Settings");
        BackButton1 = GameObject.Find("BackButton1").GetComponent<Button>();
        /*
        VoiceButton = GameObject.Find("VoiceButton").GetComponent<Button>();
        VoiceText = GameObject.Find("VoiceText").GetComponent<Text>();
        MusicButton = GameObject.Find("MusicButton").GetComponent<Button>();
        */
        
        HowtoPlay = GameObject.Find("HowToPlay");
        BackButton2 = GameObject.Find("BackButton2").GetComponent<Button>();
        
        ChooseCar = GameObject.Find("ChooseCar");
        BackButton3 = GameObject.Find("BackButton3").GetComponent<Button>();
        Car1Button = GameObject.Find("Car1").GetComponent<Button>();
        Car2Button = GameObject.Find("Car2").GetComponent<Button>();
        Car3Button = GameObject.Find("Car3").GetComponent<Button>();
        Car4Button = GameObject.Find("Car4").GetComponent<Button>();
        
        WayPanel = GameObject.Find("WayPanel");
        BackButton4 = GameObject.Find("BackButton4").GetComponent<Button>();
        way1Button = GameObject.Find("Way1").GetComponent<Button>();
        way2Button = GameObject.Find("Way2").GetComponent<Button>();
    }

    private void Start()
    {
        Entry.SetActive(true);
        Settings.SetActive(false);
        HowtoPlay.SetActive(false);
        ChooseCar.SetActive(false);
        WayPanel.SetActive(false);
        
        QuitButton.onClick.AddListener(QuitGame);
        
        SettingsButton.onClick.AddListener(OpenSettings);
        BackButton1.onClick.AddListener(CloseSettings);
        
        HowtoPlayButton.onClick.AddListener(OpenHtp);
        BackButton2.onClick.AddListener(CloseHtp);
        
        PlayButton.onClick.AddListener(OpenChooseCar);
        BackButton3.onClick.AddListener(CloseChooseCar);
        BackButton4.onClick.AddListener(CloseWayPanel);

        Car1Button.onClick.AddListener(Car1Choosing);
        Car2Button.onClick.AddListener(Car2Choosing);
        Car3Button.onClick.AddListener(Car3Choosing);
        Car4Button.onClick.AddListener(Car4Choosing);
        
        way1Button.onClick.AddListener(Way1Choosing);
        way2Button.onClick.AddListener(Way2Choosing);
        
          
        //VoiceButton.onClick.AddListener(CloseVoice);
        
        TotalMoney = PlayerPrefs.GetInt("Para1") + PlayerPrefs.GetInt("Para2") + PlayerPrefs.GetInt("Para3") +
                     PlayerPrefs.GetInt("Para4") + TotalMoney;

        PlayerPrefs.SetInt("Hesap", TotalMoney);
        // Debug.Log(PlayerPrefs.GetInt("Hesap")); -> para eklentisi ve market sistemi 
    }
    

    #region Çıkış
    private void QuitGame()
    {
        Application.Quit();
    }
    #endregion
    
    #region AyarlaraGirÇık
     
    private void OpenSettings()
    {
        Settings.SetActive(true);
        Entry.SetActive(false);
    }
    
    private void CloseSettings()
    {
        Settings.SetActive(false);
        Entry.SetActive(true);
    }
    
    #endregion
    
    #region NasılOynanırGirÇık

    private void OpenHtp()
    {
        HowtoPlay.SetActive(true);
        Entry.SetActive(false);
    }

    private void CloseHtp()
    {
        HowtoPlay.SetActive(false);
        Entry.SetActive(true);
    }
    
    #endregion
    
    #region ArabaSeçimineGirÇık
    
    private void OpenChooseCar()
    {
        ChooseCar.SetActive(true);
        Entry.SetActive(false);
    }

    private void CloseChooseCar()
    {
        ChooseCar.SetActive(false);
        Entry.SetActive(true);
    }
    #endregion

    #region ArabaSeçimleri

    // burayı daha sonra delegate ile yapıp kısaltcam
    private void Car1Choosing()
    {
        PlayerPrefs.SetInt("araba",1);
        ChooseCar.SetActive(false);
        WayPanel.SetActive(true);
    }
    private void Car2Choosing()
    {
        PlayerPrefs.SetInt("araba",2);
        ChooseCar.SetActive(false);
        WayPanel.SetActive(true);
    }
    private void Car3Choosing()
    {
        PlayerPrefs.SetInt("araba",3);
        ChooseCar.SetActive(false);
        WayPanel.SetActive(true);
    }
    
    private void Car4Choosing()
    {
        PlayerPrefs.SetInt("araba",4);
        ChooseCar.SetActive(false);
        WayPanel.SetActive(true);
    }
    #endregion

    #region YolSeç

    private void Way1Choosing()
    {
        PlayerPrefs.SetInt("yol",1);
        SceneManager.LoadScene(2);
    }
    private void Way2Choosing()
    {
        PlayerPrefs.SetInt("yol",2);
        SceneManager.LoadScene(2);
    }

    private void CloseWayPanel()
    {
        WayPanel.SetActive(false);
        ChooseCar.SetActive(true);
    }
    
    #endregion

    #region SesAyarı
    /*
    private void CloseVoice()
    {
        if (VoiceCheck == false)
        {
            VoiceCheck = true;
            VoiceText.text = "Ses Acik";
            Edit = 1;
            PlayerPrefs.SetInt("SesKontrol",Edit);
        }
        else
        {
            VoiceCheck = false;
            VoiceText.text = "SesKapali";
            Edit = 0;
            PlayerPrefs.SetInt("SesKontrol",Edit);
        }
    }
    */
    
    #endregion
}

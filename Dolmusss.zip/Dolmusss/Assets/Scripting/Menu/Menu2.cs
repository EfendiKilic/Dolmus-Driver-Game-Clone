﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class Menu2 : MonoBehaviour
{
    private GameObject Transition;
    private Button StartButton;
    private Button BackMenuButton;

    private void Awake()
    {
        Transition = GameObject.Find("Transition");
        StartButton = GameObject.Find("StartButton").GetComponent<Button>();
        BackMenuButton = GameObject.Find("BackMenuButton").GetComponent<Button>();
    }

    private void Start()
    {
        Transition.SetActive(true);
        
        StartButton.onClick.AddListener(StartToGame);
        BackMenuButton.onClick.AddListener(BacktoFirstMenu);
    }

    private void StartToGame()
    {
        if (PlayerPrefs.GetInt("yol") == 1)
        {
            SceneManager.LoadScene(3);
        }
        else if (PlayerPrefs.GetInt("yol") == 2)
        {
            SceneManager.LoadScene(4);
        }
    }

    
    private void BacktoFirstMenu()
    {
        SceneManager.LoadScene(0);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarInput : MonoBehaviour
{
    public GameObject[] Cars = new GameObject[4];
    public GameObject[] Destroyers = new GameObject[4];
    private void Start()
    {
        switch (PlayerPrefs.GetInt("araba"))
        {
            case 1:
                Instantiate(Cars[0], new Vector3(0,3.25f,-70.2f), Quaternion.Euler(0,90,0));
                Destroyers[1].SetActive(false);
                Destroyers[2].SetActive(false);
                Destroyers[3].SetActive(false);
                break;
            case 2:
                Instantiate(Cars[1], new Vector3(0,2.8f,-70.2f), Quaternion.Euler(0,0,0));
                Destroyers[0].SetActive(false);
                Destroyers[2].SetActive(false);
                Destroyers[3].SetActive(false);
                break;
            case 3:
                Instantiate(Cars[2], new Vector3(0,3.35f,-70.2f), Quaternion.Euler(0,270,0));
                Destroyers[0].SetActive(false);
                Destroyers[1].SetActive(false);
                Destroyers[3].SetActive(false);
                break;
            case 4:
                Instantiate(Cars[3],new Vector3(0,3.25f,-70.2f), Quaternion.Euler(0,0,0));
                Destroyers[0].SetActive(false);
                Destroyers[1].SetActive(false);
                Destroyers[2].SetActive(false);
                break;
        }
    }
}

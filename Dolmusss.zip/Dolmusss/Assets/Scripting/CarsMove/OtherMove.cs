﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OtherMove : MonoBehaviour
{
    private GameObject OCar;
    private Rigidbody OCarRb;
    private float speed;
    
    private void Awake()
    {
        speed = UnityEngine.Random.Range(15, 45);
        OCar = this.gameObject;
        OCarRb = this.gameObject.GetComponent<Rigidbody>();
    }

    private void Update()
    {
        Move();
    }

    private void Move()
    {
        OCarRb.velocity = Vector3.forward * speed;
    }
    
}

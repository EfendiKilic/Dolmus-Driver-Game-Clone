﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.UIElements;
using Button = UnityEngine.UI.Button;

public class Car1Move : MonoBehaviour
{
    private GameObject Car1;
    private Rigidbody Car1Rb;
    private bool LeftCheck;
    private bool RightCheck;
    private float SideSpeed = 5f;
    public float ForwardSpeed = 5f;
    private float increase;
    private Button Brake;
    private bool BrakeCheck;
    private Button Nitro;
    private bool NitroCheck;
    private float NitroTimer = 2f;

    public GameObject[] Ways;
    private GameObject Creator;
    private int RandomWay;
    private int RandomWay2;
    private float Length;
    private float Index = 1;
    private int Edit = 0;
    
    public GameObject[] Ways2;
    private int RandomWay21;
    private int RandomWay22;
    private float Length2;
    private float Index2 = 1;
    private int Edit2 = 0;

    public GameObject[] OCar = new GameObject[11];
    private Vector3[] Locations = new Vector3[4];
    private int LocationIndex;
    private int OCarIndex;
    
    public GameObject[] OCar2 = new GameObject[11];
    private Vector3[] Locations2 = new Vector3[4];
    private int LocationIndex2;
    private int OCarIndex2;

    /*
    public GameObject[] Passangers = new GameObject[4];
    private Vector3[] PassangersLocations = new Vector3[4];
    private int PassangerLocationIndex;
    private int PassangerIndex;
    */
    
    private Text PassangerText;
    private int PassangerInside = 0;
    private Text MoneyText;
    private int Money = 0;
    private int fee = 5;

    [SerializeField] private AudioClip[] Sounds;
    [SerializeField] private AudioClip[] StartDriverSounds;
    private AudioSource AudioSource;
    private float Timer = 8f;
    
    private float PoliceTimer = 5f;

    private GameObject CezaPanel;
    private float CezaSayac = 1f;
    
    private GameObject LosePanel;
    private Button PlayAgain;
    private Button Menu;
    private Text Gain;
    
    public bool kilit = false;

    private void Awake()
    {
        Time.timeScale = 1f;
        Car1 = this.gameObject;
        Car1Rb = this.gameObject.GetComponent<Rigidbody>();
        Brake = GameObject.Find("Brake").GetComponent<Button>();
        PassangerText = GameObject.Find("Passanger").GetComponent<Text>();
        MoneyText = GameObject.Find("Money").GetComponent<Text>();
        Creator = GameObject.FindWithTag("creator");

        AudioSource = this.gameObject.GetComponent<AudioSource>();

        CezaPanel = GameObject.Find("CezaPanel");
        LosePanel = GameObject.FindWithTag("LosePanel");
        PlayAgain = GameObject.Find("PlayAgain").GetComponent<Button>();
        Menu = GameObject.Find("Menu").GetComponent<Button>();
        Gain = GameObject.Find("Gain").GetComponent<Text>();

        Nitro = GameObject.Find("Nitro").GetComponent<Button>();
    }

    private void Start()
    {
        CezaPanel.SetActive(false);
        LosePanel.SetActive(false);
        
        AudioSource.PlayOneShot(StartDriverSounds[UnityEngine.Random.Range(0,StartDriverSounds.Length)]);

        PlayAgain.onClick.AddListener(Repeat);
        Menu.onClick.AddListener(ReturnToMenu);

        PassangerText.text = "0 / 10";
    }
    
    private void Update()
    {
        Acceleration();
        Police();
        Nitrous();
        Audios();
        ceza();
    }

 
    private void FixedUpdate()
    {
        Car1Rb.velocity = Vector3.forward * ForwardSpeed;

        if (NitroCheck == true)
        {
            Car1Rb.velocity = Vector3.forward * ForwardSpeed * 2f;
        }
        
        if (BrakeCheck == true)
        {
            ForwardSpeed -= Time.deltaTime * 20f;
            SideSpeed -= Time.deltaTime * 3.5f;
        }
        
        if (LeftCheck == true)
        {
            Car1Rb.velocity = Vector3.left * SideSpeed + Vector3.forward * ForwardSpeed;
        }
        else if (RightCheck == true)
        {
            Car1Rb.velocity = Vector3.right * SideSpeed + Vector3.forward * ForwardSpeed;
        }
    }

  
    private void OnTriggerEnter(Collider other)
    {
        if (PlayerPrefs.GetInt("yol") == 1)
        {
            if (other.gameObject.tag == "creator")
            {
                if (Edit == 0)
                {
                    Length = Creator.transform.position.z + 477.9f * Index;
                    RandomWay2 = UnityEngine.Random.Range(0, Ways.Length-1);
                    Instantiate(Ways[RandomWay2], new Vector3(0,0,Length), Quaternion.identity);
                    Index++;
                    Edit++;
                }
                else if(Edit == 1)
                {
                    Length = Creator.transform.position.z + 477.9f * Index;
                    RandomWay = UnityEngine.Random.Range(0, Ways.Length);
                    Instantiate(Ways[RandomWay], new Vector3(0,0,Length), Quaternion.identity);
                    Index++;
                }
            }
        }

        
        if (PlayerPrefs.GetInt("yol") == 2)
        {
            if (other.gameObject.tag == "creator")
            {
                if (Edit2 == 0)
                {
                    Length2 = Creator.transform.position.z + 477.9f * Index2;
                    RandomWay22 = UnityEngine.Random.Range(0, Ways2.Length-1);
                    Instantiate(Ways2[RandomWay22], new Vector3(0,0,Length2), Quaternion.identity);
                    Index2++;
                    Edit2++;
                }
                else if(Edit2 == 1)
                {
                    Length2 = Creator.transform.position.z + 477.9f * Index2;
                    RandomWay21 = UnityEngine.Random.Range(0, Ways2.Length);
                    Instantiate(Ways2[RandomWay21], new Vector3(0,0,Length2), Quaternion.identity);
                    Index2++;
                }
            }
        }
        
        if (other.gameObject.layer == 15 && other.gameObject.name != "Destroyer")
        {
            LocationIndex = UnityEngine.Random.Range(0, Locations.Length);
            OCarIndex = UnityEngine.Random.Range(0, OCar.Length);
            
            Locations[0] = new Vector3(-13.83f, OCar[OCarIndex].transform.position.y, other.gameObject.transform.position.z + 350f);
            Locations[1] = new Vector3(-4.81f, OCar[OCarIndex].transform.position.y, other.gameObject.transform.position.z + 350f);
            Locations[2] = new Vector3(4.26f, OCar[OCarIndex].transform.position.y, other.gameObject.transform.position.z + 350f);
            Locations[3] = new Vector3(13.72f, OCar[OCarIndex].transform.position.y, other.gameObject.transform.position.z + 330f);
            
            Instantiate(OCar[OCarIndex],Locations[LocationIndex], OCar[OCarIndex].transform.rotation);
        }
        
        if (other.gameObject.layer == 15 && other.gameObject.name != "Destroyer")
        {
            LocationIndex2 = UnityEngine.Random.Range(0, Locations2.Length);
            OCarIndex2 = UnityEngine.Random.Range(0, OCar2.Length);

            Locations2[0] = new Vector3(-36.75f, OCar2[OCarIndex2].transform.position.y, other.gameObject.transform.position.z + 350f);
            Locations2[1] = new Vector3(-46f, OCar2[OCarIndex2].transform.position.y, other.gameObject.transform.position.z + 350f);
            Locations2[2] = new Vector3(-55f, OCar2[OCarIndex2].transform.position.y, other.gameObject.transform.position.z + 350f);
            Locations2[3] = new Vector3(-64.5f, OCar2[OCarIndex2].transform.position.y, other.gameObject.transform.position.z + 330f);
            
            Instantiate(OCar2[OCarIndex2],Locations2[LocationIndex2], OCar2[OCarIndex2].transform.rotation);    
        }
        /*
        if (other.gameObject.layer == 15 && other.gameObject.name != "Destroyer")
        {
            PassangerLocationIndex = UnityEngine.Random.Range(0, PassangersLocations.Length);
            PassangerIndex = UnityEngine.Random.Range(0, Passangers.Length);

            PassangersLocations[0] = new Vector3(-13.83f, Passangers[PassangerIndex].transform.position.y, other.gameObject.transform.position.z + 350f);
            PassangersLocations[1] = new Vector3(-4.81f, Passangers[PassangerIndex].transform.position.y, other.gameObject.transform.position.z + 350f);
            PassangersLocations[2] = new Vector3(4.26f, Passangers[PassangerIndex].transform.position.y, other.gameObject.transform.position.z + 350f);
            PassangersLocations[3] = new Vector3(13.72f, Passangers[PassangerIndex].transform.position.y, other.gameObject.transform.position.z + 330f);
            
            Instantiate(Passangers[PassangerIndex],PassangersLocations[PassangerLocationIndex], Passangers[PassangerIndex].transform.rotation);    
        }
        */
        if (other.gameObject.layer == 12)
        {
            kilit = true;
            PlayerPrefs.SetInt("Para1",Money);
            Gain.text = PlayerPrefs.GetInt("Para1").ToString();
            LosePanel.SetActive(true);
            Time.timeScale = 0f;
        }
        
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.layer == 17 && other.gameObject.tag == "Passangers")
        {
            if (PassangerInside < 10)
            {
                PassangerInside++;
                Destroy(other.gameObject);
                PassangerText.text = PassangerInside.ToString() + " / 10";
            }
        }

        if (other.gameObject.layer == 18)
        {
            Money += fee * PassangerInside;
            PassangerInside = 0;
            PassangerText.text = PassangerInside.ToString() + " / 10";
            MoneyText.text = Money.ToString();
        }
    }

    private void Audios()
    {
        Timer -= Time.deltaTime;
        
        if (Timer <= 0)
        {
            AudioSource.PlayOneShot(Sounds[UnityEngine.Random.Range(0,Sounds.Length)]);
            Timer = UnityEngine.Random.Range(8, 12);
        }
    }
    
    private void Nitrous()
    {
        if (NitroCheck == true)
        {
            NitroTimer -= Time.deltaTime;
            if (NitroTimer < 0)
            {
                NitroCheck = false;
                Nitro.interactable = false;
            }
        }
    }
    private void Police()
    {
        if (this.gameObject.transform.position.x > 19.5f)
        {
            PoliceTimer -= Time.deltaTime;
        }

        else
        {
            PoliceTimer = 5f;
        }

        if (PoliceTimer <= 0)
        {
            Money -= 50;
            MoneyText.text = Money.ToString();
            PoliceTimer = 5f;
            
            CezaPanel.SetActive(true);
        }
    }

    private void ceza()
    {
        CezaSayac -= Time.deltaTime;
        if (CezaSayac < 0)
        {
            CezaPanel.SetActive(false);
            CezaSayac = 1f;
        }
    }
    
    private void Acceleration()
    {
        if (this.gameObject.transform.position.z > -75)
        {
            ForwardSpeed += increase;
        }
  
        if (ForwardSpeed <= 10)
        {
            increase = Time.deltaTime * 20;
            SideSpeed = 5f;
        }
        else if (ForwardSpeed > 10 && ForwardSpeed <= 15)
        {
            increase = Time.deltaTime * 15f;
            SideSpeed = 7f;
        }
        else if (ForwardSpeed > 15 && ForwardSpeed <= 20)
        {
            increase = Time.deltaTime * 12f;
            SideSpeed = 10f;
        } 
        else if (ForwardSpeed > 20 && ForwardSpeed <= 30)
        {
            increase = Time.deltaTime * 10f;
            SideSpeed = 12.5f;
        }
        else if (ForwardSpeed > 30 && ForwardSpeed <= 40)
        {
            increase = Time.deltaTime * 8f;
            SideSpeed = 16f;
        }
        else if (ForwardSpeed > 40 && ForwardSpeed <= 55)
        {
            increase = Time.deltaTime * 7f;
            SideSpeed = 17f;
        }
        else if (ForwardSpeed > 55 && ForwardSpeed <= 70)
        {
            increase = Time.deltaTime * 5f;
            SideSpeed = 17.5f;
        }
        else if (ForwardSpeed > 70 && ForwardSpeed <= 85)
        {
            increase = Time.deltaTime * 2f;
            SideSpeed = 17.5f;
        }
        else if(ForwardSpeed > 85 && ForwardSpeed <= 100)
        {
            increase = Time.deltaTime / 15f;
            SideSpeed = 17.5f;
        }

    }
    
    private void Repeat()
    {
        SceneManager.LoadScene(3);
    }

    private void ReturnToMenu()
    {
        SceneManager.LoadScene(1);
    }

    
    public void LeftDown()
    {
        LeftCheck = true;
    }

    public void LeftUp()
    {
        LeftCheck = false;
    }
    
    public void RightDown()
    {
        RightCheck = true;
    }

    public void RightUp()
    {
        RightCheck = false;
    }
    public void BrakeDown()
    {
        BrakeCheck = true;
    }

    public void BrakeUp()
    {
        BrakeCheck = false;
    }
    
    public void NitroDown()
    {
        NitroCheck = true;
    }

    public void NitroUp()
    {
        NitroCheck = false;
    }
}
